<?php

$con=mysqli_connect("ftp.le-text.co.bw","letexikm","4m6^7@k5#IkH","letexikm_letext");

?>