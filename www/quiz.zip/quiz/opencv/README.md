# openCV-js    ![ScreenShot](/install-opencv-3-on-ubuntu.jpg)
This contains compiled javascript version of OpenCV with default CMAKE flags

The steps taken were as instructed on [this repo](https://github.com/opencv/opencv/tree/master/platforms/js) 

## To see the working ,follow the steps
```bash
git clone https://github.com/shkrwnd/openCV-js.git
```
```bash
cd openCV-js
```
Open index.html in any supported browser.
If first line of web-page shows ```OpenCV.js is ready``` that means it is working properly.
Then just choose any image and it will show that image in new canvas <dir> block.
***
..* Just remember to use the proper path in ```<script src="path/to/opencv.js"></script> ``` when working from different directory.


