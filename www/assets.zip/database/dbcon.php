<?php
$con = mysqli_connect("ftp.thewebs.in","thewebs3_thewebs","adi0618337","thewebs3_thewebs");

// Check connection
if (mysqli_connect_errno())
  {
  echo "Failed to connect to MySQL: " . mysqli_connect_error();
  }
?>