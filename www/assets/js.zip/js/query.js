

$('#submit-message').click(function(e) {
      alert($(this).val());
      //alert(e.which);

    if (e.which==13) {
       //alert('enter is pressed');
       $('#message_form').submit();
    }
    
    });

$('#subscribe_btn').click(function(e) {
      //alert($(this).val());
      //alert(e.which);

    if (e.which==13) {
       //alert('enter is pressed');
       $('#subscribe_form').submit();
    }
    
    });

    $('#message_form').submit(function() {
        // body...
        alert("hello");
          var email=$('#mes-email').val();
          var name=$('#mes-name').val();
          //var subject=$('#contact_subject').val();
          var message=$('#mes-text').val();
          
          
        // var group_id=<?php echo $_REQUEST['group_id'];?>;
        
        $.post('../../database/php/contact.php?contact=1',{email:email,name:name,message:message},function(response){
        
           if (response.includes("wrong")) {
                document.getElementById('messagefrm').reset();
             bootbox.alert("Please Insert All Feilds !");
            

          }else if(response==1) {
             bootbox.alert("Thanks for contact us . We will inform you soon ! ");
          }else{
            bootbox.alert("You have entered wrong information");
          }

        });
        return false;
          // not refress the webpage  ,without it will refress the page

       });




 $('#subscribe_form').submit(function() {
        // body...
          var email=$('#subscribe_email').val();
          
          

        $.post('database/contact.php?subscribe=1',{email:email},function(response){
        
           if (response.includes("wrong")) {
                document.getElementById('messagefrm').reset();
             bootbox.alert("Please Enter Email !");
            

          }else if(response==1) {
             bootbox.alert("Thanks for Subscribe . We will notify you our latest news ! ");
          }else{
            bootbox.alert("You have entered wrong information");
          }

        });
        return false;
          // not refress the webpage  ,without it will refress the page

       });
